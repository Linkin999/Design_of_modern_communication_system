clear;clc;
load('data_aoa.mat')
%% reference
data = Data_aoa(9:12,:);

%% surveillance
% data = Data_aoa(1:8,:);

%% initialization
f = 2.12e9;                  % frequency
c = 2.997e8;                 % speed
lambda = c/f;                % wavelength
d = 0.07;                    % array element spacing
M = 4;                       % number of array elements
X = data;                    % received signal
N = length(X);               % number of snapshot
dd = (0:M-1)'*d;             % distance between array elements and reference element
noiseThreshold = 0.95;       % noise threshold

%% calculate the covariance matrix of received data and do eigenvalue decomposition
Rxx = X*X'/N;                                   % covariance matrix
[U,V] = eig(Rxx);                               % eigenvalue decomposition
V = diag(V);                                    % vectorize eigenvalue matrix
[V,idx] = sort(V,'descend');                    % sort the eigenvalues in descending order
U = U(:,idx);                                   % reset the eigenvector
P = sum(V);                                     % power of received data
P_cum = cumsum(V);                              % cumsum of V

%% define the noise space
Noise = find(P_cum/P >= noiseThreshold);
Noise = Noise(1);                               % number of principal component
Un = U(:,Noise+1:end);

%% music for doa; seek the peek
theta = -90:0.5:90;                             % steer theta
doa_a = exp(-1j*2*pi*dd*sind(theta)/lambda);    % manifold array for seeking peak
music = abs(diag(1./(doa_a'*(Un*Un')*doa_a)));  % the result of each theta
music = 10*log10(music/max(music));             % normalize the result and convert it to dB

%% plot
figure(1);
plot(theta, music, 'linewidth', 1.5);
title('Music Algorithm For Doa', 'fontsize', 16);
xlabel('Theta(°)', 'fontsize', 16);
ylabel('Spatial Spectrum(dB)', 'fontsize', 16);
xlim([-90 90]);
grid on;
