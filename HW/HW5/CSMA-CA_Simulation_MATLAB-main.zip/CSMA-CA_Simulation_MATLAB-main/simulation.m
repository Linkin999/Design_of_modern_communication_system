CWinit = 15;
TT = 30;
IFS = 1;
K = rand([0 CWinit],N,1)
Tt = TT + IFS + K;